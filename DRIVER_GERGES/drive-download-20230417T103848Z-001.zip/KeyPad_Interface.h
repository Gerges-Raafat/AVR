/*
 * KeyPad_Interface.h
 *
 * Created: 04/04/2023 23:37:36
 *  Author: lenovo
 */ 


#ifndef KEYPAD_INTERFACE_H_
#define KEYPAD_INTERFACE_H_



#define  NO_KEY   'T'

void KEYPAD_Init(void);

u8 KEYPAD_GetKey(void);






#endif /* KEYPAD_INTERFACE_H_ */